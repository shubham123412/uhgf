package com.entity;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.entity.layer1.Fundtransfer;
import com.entity.layer2.FundTransferRepository;

@SpringBootTest
class OnlineBankingNewApplicationTests {
	
	@Autowired
	FundTransferRepository a;

	@Test
	void contextLoads() {
		
		List<Fundtransfer> f=a.getAllRecords("111");
		
		for(Fundtransfer ab:f)
		{
			System.out.println(ab.getAmount());
		}
		
	}

}
